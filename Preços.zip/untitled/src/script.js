const btnMensal = document.getElementById("btnMensal");
const btnAvulso = document.getElementById("btnAvulso");

const precoBasic = document.getElementById("precoBasic");
const precoMedium = document.getElementById("precoMedium");
const precoPremium = document.getElementById("precoPremium");

btnMensal.addEventListener("click", () => {
  btnMensal.classList.add("active");
  btnAvulso.classList.remove("active");

  precoBasic.textContent = "R$ 70/mês";
  precoMedium.textContent = "R$ 89,90/mês";
  precoPremium.textContent = "R$ 123/mês";
});

btnAvulso.addEventListener("click", () => {
  btnAvulso.classList.add("active");
  btnMensal.classList.remove("active");

  precoBasic.textContent = "R$ 794,04";
  precoMedium.textContent = "R$ 971";
  precoPremium.textContent = "R$ 1.255,28";
});
